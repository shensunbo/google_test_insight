# google_test_insight
google test(gtest) insight

# build 
```
mkdir build
cd build/
cmake ..
make
```

# run unit test
`../runTest.sh`
